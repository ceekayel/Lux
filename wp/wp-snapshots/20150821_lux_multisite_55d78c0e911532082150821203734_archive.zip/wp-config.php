<?php
/**
 * The base configurations of the WordPress.
 *
 * This file has the following configurations: MySQL settings, Table Prefix,
 * Secret Keys, and ABSPATH. You can find more information by visiting
 * {@link https://codex.wordpress.org/Editing_wp-config.php Editing wp-config.php}
 * Codex page. You can get the MySQL settings from your web host.
 *
 * This file is used by the wp-config.php creation script during the
 * installation. You don't have to use the web site, you can just copy this file
 * to "wp-config.php" and fill in the values.
 *
 * @package WordPress
 */
/**
 * The basic unique website domain
 */
$hostingsite = "trick-e";
$website = "lux";

/**
 * WordPress Database Table prefix.
 */
$table_prefix  = 'wp_lux_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 */
define('WP_DEBUG', true);

/** The name of the database for WordPress */
define('DB_NAME', 'wp_lux');

/** MySQL database username */
define('DB_USER', 'lux');

/** MySQL database password */
define('DB_PASSWORD', 'lux!blox');

/** MySQL hostname */
define('DB_HOST', 'lux.local');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');


/**
 * Include settings.[environment].php
 *
 * Get the http host and then start removing pieces to eventually end up with
 * an environment identifier. The default environment is 'production'.
 *
 * Examples:
 *   yoursite.com = production
 *   www.yoursite.com = production
 *   yoursite.hostingsite.com = production
 *   stage.yoursite.hostingsite.com = stage
 *   stage.yoursite.com = stage
 *   local.yoursite.com = local
 *   local.yoursite = local
 *   yoursite.local = local
 */
$host = $_SERVER['HTTP_HOST'];
$origin = $_SERVER['HTTP_ORIGIN']; //this has http or https portion
//define('WP_HOME',$origin);
//define('WP_SITEURL',$origin);

//strip suffixes
$domain_env = str_replace('.com', '', $host);
$domain_env = str_replace('.net', '', $domain_env);
$domain_env = str_replace('.org', '', $domain_env);

//strip known site names
$domain_env = str_replace($hostingsite, '', $domain_env);
$domain_env = str_replace($website, '', $domain_env);

//strip prefixes
$domain_env = str_replace('www.', '', $domain_env);

//strip any separators on ends (.)
$domain_env = trim($domain_env, '.');

//whatever is left is the environment
$domain_env = (strlen($domain_env) >= 1) ? $domain_env : 'production';

// Prefix configuration variables with 'config_' to avoid any clashes.
$conf['config_environment'] = ucfirst($domain_env);
$conf['config_settings_file'] = 'settings.' . $domain_env . '.php';

// Check if the file exists prior to including it.
if (file_exists(dirname(__FILE__) . '/../conf' . $conf['config_settings_file'])) {
    require_once( dirname(__FILE__) . '/../conf' .  $conf['config_settings_file']);
}

/* If multisite, add these */
define('WP_ALLOW_MULTISITE', true );
define('MULTISITE', true);
define('SUBDOMAIN_INSTALL', true);
define('DOMAIN_CURRENT_SITE', $host);
define('PATH_CURRENT_SITE', '/');
define('SITE_ID_CURRENT_SITE', 1);
define('BLOG_ID_CURRENT_SITE', 1);

/* nice to have wp separated from other content */
define( 'WP_CONTENT_DIR', dirname(__FILE__) . '/../wp-content' );
define( 'WP_CONTENT_URL', $origin . '/wp-content' );

/* generally more is better than default of 40M */
define( 'WP_MEMORY_LIMIT', '256M' );

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
    define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');

