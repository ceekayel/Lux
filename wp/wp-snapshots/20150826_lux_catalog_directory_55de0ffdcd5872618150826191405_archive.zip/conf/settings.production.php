<?php
/**
 * production
 */
/**
 * WordPress Database Table prefix.
 * If you get this WRONG it'll act like you have to set up the database fresh
 */
$table_prefix  = 'wp_lux_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 */
define('WP_DEBUG', false);

/** The name of the database for WordPress */
define('DB_NAME', 'wp_lux');

/** MySQL database username */
define('DB_USER', 'lux');

/** MySQL database password */
define('DB_PASSWORD', 'lux!blox');

/** MySQL hostname */
define('DB_HOST', 'lux.local');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

